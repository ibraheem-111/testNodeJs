import inquirer from "inquirer";
import fs from "fs";
import queryDB from "./queryDB.js";
import dbFileCheck from "./dbFileCheck.js";

if(dbFileCheck("db.json")){
    console.log("it exists");
}