import queryDB from "./queryDB.js";

queryDB();